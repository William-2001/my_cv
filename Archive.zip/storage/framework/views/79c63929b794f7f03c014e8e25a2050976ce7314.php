<nav class="navbar navbar-expand-md">
    <div class="container-fluid">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <i class="fas fa-ellipsis-h" style="color: #b5b5b5"></i>
      </button>
      <div class="collapse navbar-collapse text-right" id="navbarNavAltMarkup">
        <div class="navbar-nav ms-auto">
            <a class="nav-link" href="#about">About</a>
            <a class="nav-link" href="#skills">What i do</a>
            <a class="nav-link" href="#relevant">References</a>
        </div>
      </div>
    </div>
</nav>
<?php /**PATH /Users/william_drive/Downloads/my_cv/resources/views/layouts/nav.blade.php ENDPATH**/ ?>