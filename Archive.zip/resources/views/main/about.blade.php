<div id="about" class="container-fluid py-5">
    <h1 class="header">About me</h1>
    <hr class="thick-hr">
    <div class="container-fluid about">
        <p>
            Hello my name is William Gazali, as of right now I am in Bina Nusantara university majoring in Computer science streaming in Intelligent System.
            To keep up with the materials on class and on personal interest, I learned how to study and understand the materials as fast as I can, although I usually forget quickly too, a litte revision prove to be effective in handling this weakness.
            Before Computer Science I used to be an International Marketing student for a year but decided to change my major to Computer Science due to change in passion, but I am sure that this passion is here to stay since I always vast my knowledge in the world of technologies.
            <br><br>
            I always have a thing for studying, when there is nothing to do (holiday, finish assignment, etc) I usually try to learn a new framework or hone my existing skills, though it is more fun to have a partner in studying so that we can help each other and I always have a soft spot when it comes to teaching.
            Teaching other people have thought myself to be ready more often and to understand a topic deeply, usually it gives me the motivation to study more in order to be able to teach it later.
            Needless to say, I love to teach and be tought, it is a way of keeping myself productive all these times, this is a method I used to train how fast I can learn a particular subject.
            <br><br>
            I graduated highschool with an Indian boards certificate in commerce studies, I use to be a business student before changing majors, soft skills that are expected from a business student presisted. Soft skills such as communication, leadership, public speaking, Public Relations, etc.
            So as team player, teamwork is something that I am quite proud of, I usually deliver all my work as fast as I can before the deadline, equipped with a can-do mentality, most work can be done by myself.

        </p>
    </div>
</div>
